## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = ">")
library(cholera)

## ---- fig.width = 5, fig.height = 5, fig.align = "center", echo = TRUE----
plot(timeSeries())


library(testthat)
library(statsr)

test_check("statsr")

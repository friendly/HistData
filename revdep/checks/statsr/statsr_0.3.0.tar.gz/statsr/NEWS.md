# News for statsr

# statsr 0.3.0

* merged the 'BayesFactor' branch with main branch so that the `bayes_inference` function on CRAN is consistent with book and other supplemental materials online.  Provides a more unified function and additional options.  Addresses [issue #15](https://github.com/StatsWithR/statsr/issues/15)

* Restore the tapwater and zinc data

# statsr 0.2.0
 
* updates so that functions are compatible with tibble package version 3.0.0

# statsr 0.1.0

* First release of package on CRAN to accompany version 2 of the Statistics With R course on Coursera and release of the online book [Introduction to Bayesian Thinking](https://statswithr.github.io/book/)
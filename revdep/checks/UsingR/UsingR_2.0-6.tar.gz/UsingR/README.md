Files for the `UsingR` package to accompany the book "Using R for Introductory Statistics," second edition.



#' Functionality for Data Science at IBAW
#'
#' @import dslabs
#' @importFrom magrittr %>%
#' @importFrom stats sd
#' @importFrom rlang .data :=
#' @keywords internal

"_PACKAGE"

globalVariables(".")

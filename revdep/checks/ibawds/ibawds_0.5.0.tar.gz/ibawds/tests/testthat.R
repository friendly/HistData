library(testthat)
library(ibawds)

test_check("ibawds")
